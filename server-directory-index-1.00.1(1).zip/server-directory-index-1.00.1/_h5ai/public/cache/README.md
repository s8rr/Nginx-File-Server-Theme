# Cache

Public cache.

This directory is used for server side caching. To use caching make this
directory writable by your webserver.

There is no critical data in here. You can safely remove any content. This
will clear the cache.
